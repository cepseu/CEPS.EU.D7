var cj = jQuery.noConflict(true);
